package com.liaoyun.service;

public interface OpenAccountService {
}

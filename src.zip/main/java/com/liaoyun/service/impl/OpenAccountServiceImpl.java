package com.liaoyun.service.impl;

import com.liaoyun.domain.ResponseResult;
import com.liaoyun.service.OpenAccountService;

public class OpenAccountServiceImpl implements OpenAccountService {

}

//package com.liaoyun.domain.responseType;
//
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
//import java.math.BigDecimal;
//
//@Data
//@AllArgsConstructor
//@NoArgsConstructor
//public class CardNumberAndBalance {
//    private String cardNumber;
//    private BigDecimal balance;
//}

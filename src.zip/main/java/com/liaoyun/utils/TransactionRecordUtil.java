package com.liaoyun.utils;

public class TransactionRecordUtil {
    public static void record(){

    }
}
